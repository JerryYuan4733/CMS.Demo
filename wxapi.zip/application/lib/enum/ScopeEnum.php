<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/9
 * Time: 10:15
 */

namespace app\lib\enum;


class ScopeEnum
{
    const User=16;
    const Super=32;
}