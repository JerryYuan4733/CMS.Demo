<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/18
 * Time: 11:23
 */

namespace app\lib\exception;




class TagsException extends BaseException
{
    public $code = 404;
    public $msg = '指定跳转标签不存在，请检查标签ID';
    public $errorCode = 30000;
}