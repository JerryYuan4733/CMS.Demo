<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/17
 * Time: 8:45
 */

namespace app\lib\exception;


class JumpException extends BaseException
{
    public $code = 404;
    public $msg = '指定跳转主题不存在，请检查主题ID';
    public $errorCode = 30000;
}