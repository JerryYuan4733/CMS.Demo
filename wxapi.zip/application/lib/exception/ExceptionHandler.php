<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/4/20
 * Time: 11:14
 */
//异常处理类
namespace app\lib\exception;


use Exception;
use think\exception\Handle;
use think\Log;
use think\Request;

class ExceptionHandler extends Handle
{
    private $code;
    private $msg;
    private $errorCode;
    //需要返回当前客户端的URL路径
    public function  render(\Exception $e)//所有的异常都会经过render的渲染后抛出 \表示根命名空间下的基类
    {
        if($e instanceof BaseException)
        {//如果是自定义异常
            $this->code=$e->code;
            $this->msg=$e->msg;
            $this->errorCode=$e->errorCode;

        }
        else{

            if(config('app_debug'))//开发环境下用默认的 生产环境用自定义的
            {
                return parent::render($e);
            }
            else {
                $this->code = 500;
                $this->msg = "服务器内部错误";
                $this->errorCode = 999;
                $this->recordErrorLog($e);
            }
        }
        $request=Request::instance();
        $result=[
            'msg'=>$this->msg,
            'error_code'=>$this->errorCode,
            'request_url'=>$request->url
        ];
        return json($result,$this->code);
    }

    private function  recordErrorLog(\Exception $e)
    {
        Log::init([
            'type'=>'File',
            'path'=>LOG_PATH,
            'level'=>['error']
        ]);
        Log::record($e->getMessage(),'error'); //级别为error 只有高于error级别的才会被记录
    }
}