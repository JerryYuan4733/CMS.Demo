<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/14
 * Time: 19:24
 */

namespace app\lib\exception;


class ParameterException extends BaseException
{
    public  $code=400;
    public $msg='参数错误';
    public $errorCode=10000;
}