<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/7
 * Time: 14:39
 */

namespace app\lib\exception;


class TokenException extends BaseException
{
    public $code=401;
    public $msg='Token已经过期或无效Token';
    public $errorCode=10001;
}