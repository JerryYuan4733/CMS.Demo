<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/14
 * Time: 20:15
 */

namespace app\lib\exception;


class SwiperMissException extends BaseException
{
    public $code=404;//HTTP 状态码
    public $msg='请求的Banner不存在';//错误具体信息
    public  $errorCode=40000;//自定义错误码
}