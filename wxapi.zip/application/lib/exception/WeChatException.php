<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/19
 * Time: 20:04
 */

namespace app\lib\exception;


class WeChatException extends BaseException
{
    public $code=400;//HTTP 状态码
    public $msg='微信服务接口调用失败';//错误具体信息
    public  $errorCode=999;//自定义错误码
}