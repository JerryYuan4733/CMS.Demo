<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/14
 * Time: 20:02
 */
return [
    'img_prefix'=>'http://188.131.232.68/wxapi/public/images',
    'token_expire_in'=>7200
];
