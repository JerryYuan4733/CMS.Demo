<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/19
 * Time: 17:19
 */

return [
    'token_salt'=>'JerryIsSoBrilliant'
];