<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

use think\Route;


//swiper
Route::rule('api/:version/Swiper/:id','api/:version.Swiper/getSwiper','GET');

//Jump
Route::rule('api/:version/Jump','api/:version.Jump/getJumpList','GET');

//Tags
Route::rule('api/:version/Tags','api/:version.Tags/getTags','GET');
Route::rule('api/:version/Tags/all','api/:version.Tags/getALLTags','GET');
//访问token的路由
Route::post('api/:version/token/user', 'api/:version.Token/getToken');
Route::post('api/:version/token/verify', 'api/:version.Token/verifyToken');
Route::post('api/:version/token/app', 'api/:version.Token/getAppToken');
//advice
Route::post('api/:version/project/advice', 'api/:version.Advice/uploadAdvice');


//product
Route::post('api/:version/product/user/upload', 'api/:version.Product/uploadImg');
Route::post('api/:version/product/keyword', 'api/:version.Product/keyWordSearch');
Route::get('api/:version/product/:id', 'api/:version.Product/getProductByID',[],['id'=>'\d+']);
Route::get('api/:version/product/delete', 'api/:version.Product/deleteOne');
Route::post('api/:version/product/judge/:id', 'api/:version.Product/isCollected',[],['id'=>'\d+']);
Route::post('api/:version/product/collect/:id', 'api/:version.Product/collect',[],['id'=>'\d+']);
Route::post('api/:version/product/cancel/:id', 'api/:version.Product/cancelCollect',[],['id'=>'\d+']);
Route::get('api/:version/product/tag', 'api/:version.Product/getProductsByTag');
Route::post('api/:version/product/own', 'api/:version.Product/getOwnProduct');
Route::post('api/:version/product/own/collection', 'api/:version.Product/getOwnCollection');
Route::post('api/:version/product/publish', 'api/:version.Product/publishProduct');

//Inform
Route::post('api/:version/inform', 'api/:version.Inform/createInform',[],['id'=>'\d+']);

//verify
Route::post('api/:version/idVerify', 'api/:version.IdVerify/toVerify');

//User
Route::post('api/:version/RefineUser', 'api/:version.RefineUser/RefineUserInfo');
