<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/21
 * Time: 11:38
 */

namespace app\api\validate;


class ProductPublish extends BaseValidate
{
    protected $rule = [
        'url'=>'require|isNotEmpty',
        'header' => 'require|isNotEmpty',
        'describe'=>'require',
        'date'=>'require|isNotEmpty',
        'account'=>'require|isNotEmpty',
        'phone'=>'require',
        'person'=>'require|isNotEmpty',
        'longitude'=>'require',
        'latitude'=>'require',
        'images'=>'require',
        'tags'=>'require'
    ];
}
