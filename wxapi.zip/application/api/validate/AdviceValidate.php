<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/31
 * Time: 13:43
 */

namespace app\api\validate;


class AdviceValidate extends BaseValidate
{
    protected $rule = [
        'describe' => 'require|isNotEmpty',

    ];
}