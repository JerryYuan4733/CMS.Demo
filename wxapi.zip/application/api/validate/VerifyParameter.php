<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/21
 * Time: 10:30
 */

namespace app\api\validate;


class VerifyParameter extends BaseValidate
{
    protected $rule = [
        'account'=>'require|isNotEmpty',
        'password'=>'require|isNotEmpty',

    ];

}