<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/29
 * Time: 18:59
 */

namespace app\api\validate;


class keyWord extends BaseValidate
{
    protected $rule = [
        'keyword' => 'require|isNotEmpty',
        'tag' => 'require'
    ];
}