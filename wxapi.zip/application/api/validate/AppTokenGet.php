<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/10/2
 * Time: 14:47
 */

namespace app\api\validate;


class AppTokenGet extends BaseValidate
{
    protected $rule = [
        'ac' => 'require|isNotEmpty',
        'se' => 'require|isNotEmpty'
    ];
}