<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/19
 * Time: 17:03
 */

namespace app\api\validate;


class TokenGet extends BaseValidate
{
    public $rule=[
        'code'=>'require|isNotEmpty'
    ];
    protected $message=[
        'code'=>'缺少code 无法获取Token'
    ];

}