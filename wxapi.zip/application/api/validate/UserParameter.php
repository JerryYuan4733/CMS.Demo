<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/23
 * Time: 20:38
 */

namespace app\api\validate;


class UserParameter extends BaseValidate
{
    protected $rule = [
        'nickname' => 'require|isNotEmpty',
        'avatar' => 'require|isNotEmpty'
    ];
}