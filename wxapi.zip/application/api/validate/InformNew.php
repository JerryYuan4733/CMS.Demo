<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/20
 * Time: 16:29
 */

namespace app\api\validate;


class InformNew extends BaseValidate
{
    protected $rule = [
        'product_id' => 'require|isPositiveInteger',
        'describe'=>'require|isNotEmpty',
        'label1'=>'require',
        'label2'=>'require',
        'label3'=>'require',
    ];
}