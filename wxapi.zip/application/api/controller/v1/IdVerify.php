<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/21
 * Time: 10:26
 */

namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\api\validate\VerifyParameter;
use app\api\model\IdVerify as VerifyModel;
use app\api\service\Token as TokenService;
use app\api\model\User as UserModel;

class idVerify extends BaseController
{
    public function toVerify()
    {
        $validate=new VerifyParameter();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $result = VerifyModel::get(['user_id' => $uid]);

        if($result)
        {
	    $user=UserModel::get($uid);
            $user->verified=1;
            $user->save();
            return 1;//已经验证过了
        }
        elseif(!$result)
            {
            $data = $validate->getDataByRule(input('post.'));
                $result2=VerifyModel::get(['account'=>$data['account'],'password'=>$data['password']]);
            if(!$result2)
            {
                return 4;//账号密码错误
            }

            elseif($result2['user_id'])
            {
                return 2;//账号密码已经有人用了
            }
            else
            {
                $result2->user_id=$uid;
                $result2->save();
		$user=UserModel::get($uid);
            	$user->verified=1;
            	$user->save();
                return 3;//账号密码验证成功
            }

        }
    }
}
