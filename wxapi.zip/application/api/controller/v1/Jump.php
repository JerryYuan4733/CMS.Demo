<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/16
 * Time: 21:04
 */

namespace app\api\controller\v1;

use app\api\controller\BaseController;
use app\api\model\Jump as JumpModel;
use app\api\validate\IDCollection;
use app\lib\exception\JumpException;
class Jump extends BaseController
{
   public function getJumpList($ids='')
   {
       $validate= new IDCollection();
       $validate->goCheck();
       $ids=explode(',',$ids);
       $result=JumpModel::with('img')->select($ids);
       if($result->isEmpty())
       {
            throw  new JumpException();
       }
        return json($result);
   }

}