<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/31
 * Time: 13:42
 */

namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\api\validate\AdviceValidate;
use app\api\service\Token as TokenService;
use app\api\model\Advice as AdviceModel;

class Advice extends BaseController
{
    public function uploadAdvice ()
    {
        $validate=new AdviceValidate();
        $validate->goCheck();
        $data = $validate->getDataByRule(input('post.'));
        $uid=TokenService::getCurrentUid();
        if($data) {
            $data['user_id'] = $uid;
            $newProduct = new AdviceModel($data);
            $newProduct->allowField(true)->save();
            return 1;
        }
        else{
            return 0;
        }
    }
}