<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/20
 * Time: 15:52
 */

namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\api\validate\InformNew;
use app\api\service\Token as TokenService;
use app\api\model\Inform as InformModel;

class Inform extends BaseController
{
    public function createInform()
    {
        $validate=new InformNew();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $data = $validate->getDataByRule(input('post.'));
        $data['user_id']=$uid;
        $inform = new InformModel();
//        $inform->data([
//            'user_id'  =>  $uid,
//            'product' =>  $data['product_id'],
//            'describe'=>$data['describe'],
//            'label_1'=>$data['label_1'],
//            'label_2'=>$data['label_2'],
//            'label_3'=>$data['label_3'],
//        ]);
        $inform->save($data);
        return $data;
    }
}