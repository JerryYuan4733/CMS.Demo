<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/18
 * Time: 20:17
 */

namespace app\api\controller\v1;

use think\Db;
use app\api\controller\BaseController;
use app\api\model\UserCollection;
use app\api\validate\IDMustBePositiveInt;
use app\api\model\Product as ProductModel;
use app\api\validate\PagingParameter;
use app\lib\exception\ParameterException;
use app\lib\exception\ProductException;
use app\api\validate\IDCollection;
use app\api\model\UserCollection as UserCollectionModel;
use app\api\service\Token as TokenService;
use app\api\model\ProductTag as ProductTagModel;
use app\api\model\Tags as TagsModel;
use app\api\model\User as UserModel;
use app\api\validate\ProductPublish;
use app\api\model\UserImage as UserImageModel;
use app\api\validate\KeyWord;




class Product extends BaseController
{

//    protected $beforeActionList = [
//        'checkExclusiveScope' => ['only' => 'placeOrder'],
//        'checkPrimaryScope' => ['only' => 'getDetail,getSummaryByUser'],
//        'checkSuperScope' => ['only' => 'delivery,getSummary']
//    ];
    protected $beforeActionList = [
//        'checkSuperScope' => ['only' => 'createOne,deleteOne'],
        'checkPrimaryScope'=>['only'=>'publishProduct']
    ];


    public function uploadImg()
    {
        $file = request()->file('file');

        if($file){
            $info = $file->move(ROOT_PATH . 'public' . DS . 'images');
            if($info)
	{
                    $filename=$info->getFilename();
                    $fileinfo=$info->getFileInfo();
                    $filepath=$info->getPathname();
		     $filepath=explode('/',$filepath);
		    $len=count($filepath);
		    $path=$filepath[$len-2].'/'.$filepath[$len-1];
			return $path;

            }else{
               
                
            }
        }
        return $file;

    }



    public function keyWordSearch()
    {
        $validate=new KeyWord();
        $validate->goCheck();
        $data = $validate->getDataByRule(input('post.'));
        $where=array();
        if($data['tag']==0)
        {
            $where['header']=['like','%'.$data['keyword'].'%'];
            $products=ProductModel::with('withUserInfo')->where($where)->select();
        }
        else
        {
            $where['header']=['like','%'.$data['keyword'].'%'];
            $tagProducts =TagsModel ::getProductsByTagID(
                $data['tag'], false);
            $products=ProductModel::with('withUserInfo')->where($where)->select();


//            $keyProducts=Db::table('product')->where($where)->buildSql();
//            $products=Db::table('product')->
//            alias('p')
//                ->join([$keyProducts=>'t'],'t.id=p.id')->select();
        }


        return $products;


    }




    public function getProductByID($id)
    {
        (new IDMustBePositiveInt())->goCheck();
        $product=ProductModel::with('imgs,tags')->find($id);//遗留：给照片排序
       //增加浏览记录-----------------
        $count=$product['view']+1;
        $temp=new ProductModel();
        $temp->save([
            'view'  => $count,

        ],['id' => $id]);
        //--------------------
        if(!$product)
        {
            throw new ProductException();
        }
        return $product;

    }


    //通过标签查找商品
    public function getProductsByTag($id=1,$page=1,$size=10)
    {
        (new IDMustBePositiveInt())->goCheck();
        (new PagingParameter())->goCheck();
        $pagingProducts =TagsModel ::getProductsByTagID(
            $id, true, $page, $size);
        if ($pagingProducts->isEmpty())
        {
            // 对于分页最好不要抛出MissException，客户端并不好处理
            return [
                'current_page' => $pagingProducts->currentPage(),
                'data' => []
            ];
        }
        $data = $pagingProducts
            ->toArray();
        // 如果是简洁分页模式，直接序列化$pagingProducts这个Paginator对象会报错
        //        $pagingProducts->data = $data;
        return [
            'current_page' => $pagingProducts->currentPage(),
            'data' => $data
        ];
//        return $pagingProducts;
    }

//获取用户自己发布的商品信息
    public function getOwnProduct()
    {
        $uid=TokenService::getCurrentUid();
        $products=ProductModel::with(['imgs','withUserInfo'])->where("user_id",'=',$uid)->select();

        if(!$products)
        {
            throw new ProductException();
        }
        return $products;

    }

    //获取用户自己收藏的商品信息
    public function getOwnCollection()
    {
        $uid=TokenService::getCurrentUid();
        $result=UserModel::with(['products.withUserInfo'])->where('id', '=', $uid)->select();

        if(!$result)
        {
            throw new ProductException();
        }
        return $result;

    }





    //发布商品
    public function publishProduct()
    {
        $validate=new ProductPublish();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $data = $validate->getDataByRule(input('post.'));
        $data['user_id']=$uid;
        $newProduct = new ProductModel($data);
        $newProduct->allowField(true)->save();
        $productID=$newProduct->id;
        $images=$data['images'];
        $tags=$data['tags'];
        if($productID) {
            $this->images($productID, $images);
            $this->tags($productID, $tags);
        }

    }

    private function images($productID,$images)
    {
        foreach ($images as $value)
        {
            $userImage = new UserImageModel([
                'product_id'  =>  $productID,
                'url' =>  $value
            ]);
            $userImage->save();
        }

    }

    private function tags($productID,$tags)
    {


        foreach ($tags as $value)
        {
            $tag=TagsModel::get($value);
            $temp=$tag->num +1;
            $tag->num=$temp;
            $productTag = new ProductTagModel([
                'product_id'  =>  $productID,
                'tag_id' =>  $value
            ]);
            $productTag->save();
        }

    }






    //检测该商品是否被收藏
    public function isCollected($id)
    {
        //需要携带令牌传入
        $validate= new IDMustBePositiveInt();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $exist=UserCollectionModel::get(['user_id'=>$uid,'product_id'=>$id]);
        if(!$exist)
        {
            return false;
        }
        return true;

    }

    //将商品加入收藏
    public function collect($id)
    {

        $validate= new IDMustBePositiveInt();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $test=self::isCollected($id);
        if(!$test)
        {
            $collect = new UserCollection();
            $collect->data([
                'user_id'  => $uid,
                'product_id' =>  $id
            ]);
            $collect->save();
            return true;
        }
        else
        {
            return false;
        }


    }

    //将商品取消收藏
    public function  cancelCollect($id)
    {

        $validate= new IDMustBePositiveInt();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $test=self::isCollected($id);
        if($test)
        {
            UserCollection::where('user_id','=',$uid)->where('product_id','=',$id)->delete();
//            UserCollection::destroy()


            return true;
        }
        else
        {
            return false;
        }


    }






    public function createOne()
    {
        $product = new ProductModel();
        $product->save(
            [
                'id' => 1
            ]);
    }

    public function deleteOne($id)
    {
        (new IDMustBePositiveInt())->goCheck();
       $product= ProductModel::with('tags')->select($id);
       $tags=$product[0]['tags'];
       $temp=[];
       for($i=0;$i<count($tags);$i++)
       {
           $sub=$tags[$i];
           $temp[$i]=$sub['id'];
       }
       foreach ($tags as $value)
       {
           $tag=TagsModel::get($value['id']);
           if($tag->num) {
               $temp2 = $tag->num - 1;
               $tag->num = $temp2;
               $tag->save();
           }
       }
        ProductModel::destroy($id);
        //        ProductModel::destroy(1,true);
        return true;
    }
}
