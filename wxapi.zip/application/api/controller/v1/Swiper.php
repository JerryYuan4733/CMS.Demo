<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/14
 * Time: 18:48
 */

namespace app\api\controller\v1;

use app\api\controller\BaseController;
use app\api\validate\IDMustBePositiveInt;
use app\lib\exception\SwiperMissException;
use app\api\model\Swiper as SwiperModel;

class Swiper extends BaseController
{
    public function getSwiper($id)
    {
        (new IDMustBePositiveInt())->goCheck();
        $swiper=SwiperModel::getSwiperById($id);
        if(!$swiper)
        {
            throw new SwiperMissException();//该操作需要让SwiperMissException继承Exception类
        }
        return json($swiper);
    }
}