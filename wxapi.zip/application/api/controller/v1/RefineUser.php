<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/23
 * Time: 20:37
 */

namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\api\validate\UserParameter;
use app\api\service\Token as TokenService;
use app\api\model\User as UserModel;
use app\lib\exception\ParameterException;

class RefineUser extends BaseController
{

    public function RefineUserInfo()
    {
        $validate=new UserParameter();
        $validate->goCheck();
        $uid=TokenService::getCurrentUid();
        $data= $validate->getDataByRule(input('post.'));
        if(!$data)
        {
            throw new ParameterException();
        }
        $user=UserModel::get($uid);
        $user->nickname=$data['nickname'];
        $user->avatar=$data['avatar'];
        $user->save();
        return $user;
    }
}