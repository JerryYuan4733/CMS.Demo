<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/18
 * Time: 11:08
 */

namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\api\model\Tags as TagsModel;
use app\api\validate\IDCollection;
use app\lib\exception\TagsException;

class Tags extends BaseController
{
    public function getTags($ids)
    {
        $validate= new IDCollection();
        $validate->goCheck();
        $ids=explode(',',$ids);
        $result=TagsModel::with('tag_img')->select($ids);
        if($result->isEmpty())
        {
            throw  new TagsException();
        }
        return json($result);
    }

    public function getAllTags()
    {
        $result=TagsModel::with('tag_img')->select();
        if($result->isEmpty())
        {
            throw  new TagsException();
        }
        return json($result);
    }
}