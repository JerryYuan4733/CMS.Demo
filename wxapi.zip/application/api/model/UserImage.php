<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/20
 * Time: 13:55
 */

namespace app\api\model;


class UserImage extends BaseModel
{

}