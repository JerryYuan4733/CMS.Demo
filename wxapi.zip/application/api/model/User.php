<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/19
 * Time: 17:08
 */

namespace app\api\model;


class User extends BaseModel
{
    //关联

    public  static function getByOpenID($openid)
    {
        $user=self::where('openid','=',$openid)->find();
        return $user;
    }
    public function Products()
    {
        return $this->belongsToMany('Product','user_collection','product_id','user_id');
    }
}