<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/10/2
 * Time: 14:57
 */

namespace app\api\model;

use think\Model;

class ThirdApp extends BaseModel
{
    public static function check($ac, $se)
    {
        $app = self::where('app_id','=',$ac)
            ->where('app_secret', '=',$se)
            ->find();
        return $app;

    }
}
