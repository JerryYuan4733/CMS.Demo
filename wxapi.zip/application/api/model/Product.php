<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/18
 * Time: 20:17
 */

namespace app\api\model;


class Product extends BaseModel
{
    public function imgs()
    {
        return $this->hasMany('UserImage', 'product_id', 'id');
    }
    public function withUserInfo()
    {
        return $this->belongsTo('User','user_id','id');
    }
    public function tags()
    {
        return $this->belongsToMany('Tags','product_tag','tag_id','product_id');
    }
    public function user()
    {
        return $this->belongsToMany('User','user_collection','user_id','product_id');
    }

}