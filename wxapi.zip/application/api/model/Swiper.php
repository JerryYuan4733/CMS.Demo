<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/14
 * Time: 19:30
 */
namespace app\api\model;
use app\api\validate\IDMustBePositiveInt;

class Swiper extends BaseModel
{
    protected $hidden=['update_time','delete_time'];
    public function  items()//关联
    {
        //hasMany 一对多
        return $this->hasMany("SwiperItem",'swiper_id','id');
        // 参数： 关联模型的模型名称 关联模型的外键 当前模型的主键
    }
    public static function  getSwiperById($id)
    {
        //TODO：根据id号码 获取banner信息
        $Swiper=self::with(['items','items.img'])->find($id);
        return $Swiper;//返回的是一个对象
    }

}