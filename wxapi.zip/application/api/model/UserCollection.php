<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/20
 * Time: 15:10
 */

namespace app\api\model;


class UserCollection extends BaseModel
{

}