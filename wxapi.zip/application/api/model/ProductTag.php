<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/20
 * Time: 18:42
 */

namespace app\api\model;


class ProductTag extends BaseModel
{


}