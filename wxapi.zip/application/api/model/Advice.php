<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/31
 * Time: 13:57
 */

namespace app\api\model;


class Advice extends BaseModel
{

}