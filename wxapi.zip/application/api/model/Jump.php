<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/17
 * Time: 8:19
 */

namespace app\api\model;


class Jump extends BaseModel
{
    public function img()
    {
        return $this->belongsTo("Image","img_id","id");
    }
}