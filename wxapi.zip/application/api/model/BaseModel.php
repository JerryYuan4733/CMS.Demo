<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/14
 * Time: 19:49
 */

namespace app\api\model;


use think\Model;

class BaseModel extends Model
{
    //将 image里面的url 补充完整
    public function prefixImgUrl($value,$data)
    {
        $finalUrl = $value;
        if ($data['from'] == 1) {

            $finalUrl = config('setting.img_prefix') . $value;
        }
        return $finalUrl;
    }
}