<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/18
 * Time: 11:08
 */

namespace app\api\model;
use app\api\model\Product as ProductModel;

class Tags extends BaseModel
{
    public function tagImg()
    {
        return $this->belongsTo('Image','img_id','id');
    }


    public function products()
    {
        return $this->belongsToMany('Product','product_tag','product_id','tag_id');
    }
    public static function getProductsByTagID($tag_id,$paginate = true,$page=1,$size=10)
    {
        $query = self::with(
            ['products'=>function($query)
            {
                $query->with('imgs');
            }])->with('products.withUserInfo')->
//        with('products.withUserInfo')->
        where('id', '=', $tag_id);
//        $query2=self::with('products.imgs')->where('id', '=', $tag_id)->select();
        if (!$paginate)
        {
            return $query->buildSql();
        }
        else
        {
//            return $query->select();
            // paginate 第二参数true表示采用简洁模式，简洁模式不需要查询记录总数
            return $query->paginate(
                $size, true, [
                'page' => $page
            ]);


        }
    }
}