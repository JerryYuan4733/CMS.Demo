<?php
/**
 * Created by PhpStorm.
 * User: Dell
 * Date: 2019/5/21
 * Time: 10:28
 */

namespace app\api\model;


class IdVerify extends BaseModel
{

}