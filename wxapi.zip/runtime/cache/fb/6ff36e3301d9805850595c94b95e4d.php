<?php
//000000007200s:104:"{"session_key":"00q2z4GpQbSyQr3q9LA8\/Q==","openid":"oxP9F46qZffyPnMpp5JRqci1lpZ0","uid":"1","scope":16}";
?>