<?php
//000000007200s:101:"{"session_key":"6fihdMIwFCLcCy0RyfWxtg==","openid":"oxP9F46qZffyPnMpp5JRqci1lpZ0","uid":1,"scope":16}";
?>