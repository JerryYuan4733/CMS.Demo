<?php
//000000007200s:103:"{"session_key":"Vf5qfurW0OeD8ra980dVmA==","openid":"oxP9F46qZffyPnMpp5JRqci1lpZ0","uid":"1","scope":16}";
?>